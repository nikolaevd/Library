/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package windowapp;

import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;


/**
 *
 * @author lapa
 */

class AutoTableModel extends AbstractTableModel
{
    private Vector<String> colNames; // Generics 
    private Vector<Vector<String>> cells; // Generics 
    
    AutoTableModel()
    {
        super();
        colNames = new Vector<String> ();
        colNames.add("Марка автомобиля");
        colNames.add("Цена");
        
        cells = new Vector<Vector<String>> ();
        
        Vector<String> curRow;
        
        
        
        
        curRow = new Vector<String>();
        curRow.add("Lexus RX300");
        curRow.add("350000");
        
        cells.add(curRow);
        
        curRow = new Vector<String>();
        curRow.add("Land Cruiser Prado");
        curRow.add("2500000");
        
        cells.add(curRow);
                
    }
    
    public void fromQuery(ResultSet s)
    {
       cells.clear();
       
       try
       {
       while (s.next())
       {
           Vector<String> curRow = new Vector<String>();
            curRow.add(s.getString(2));
            curRow.add(s.getString(3));
            cells.add(curRow);
     //       System.out.println(s.getString(2)+" "+ s.getString(3));
       };
       } catch (SQLException e)
       {
           cells.clear();
       }
    };
    
    public int getColumnCount()
    {        
        return colNames.size();
    }
    
    public int getRowCount()
    {        
        return cells.size();
    }
    
    public Object getValueAt(int row, int column)
    {
        return cells.get(row).get(column);
    }
    
    public String getColumnName(int column)
    {
        return colNames.get(column);
    }
};

class AutoDataBase
{
    private Statement st;
    private PreparedStatement price_st; // класс объекта подготовленного запроса по цене
    private PreparedStatement mark_st; // класс объекта подготовленного запроса по марке
    private PreparedStatement price_mark_st;
    private PreparedStatement all_st;
    public AutoDataBase() throws ClassNotFoundException, SQLException
    {     
        Connection c = DriverManager.getConnection("jdbc:postgresql://data.biysk.secna.ru:5432/test", "test", "Aigee9");
        /* Установление соединения с сервером БД
        ("jdbc:postgresql://data.biysk.secna.ru:5432/test", "test", "Aigee9")  -
            ("спецификация драйвера СУБД:имя используемой СУБД://адрес сервера БД:порт/имя БД",
        "<имя пользователя>", "<пароль>")
        */
        st = c.createStatement();
        price_st = c.prepareStatement("SELECT * FROM \"Autos\" WHERE \"price\"<=?");
        mark_st = c.prepareStatement("SELECT * FROM \"Autos\" WHERE \"mark\"=?");
        price_mark_st = c.prepareStatement("SELECT * FROM \"Autos\" WHERE (\"mark\"=?) AND (\"price\"<=?)");
        all_st = c.prepareStatement("SELECT * FROM \"Autos\"");
    };
    
    ResultSet query_price(int max_price) throws SQLException
    {        
        price_st.setInt(1, max_price);
        return price_st.executeQuery();
    };
    
    ResultSet query_mark(String mark) throws SQLException
    {        
        mark_st.setString(1, mark);
        return mark_st.executeQuery();
    };
    
    ResultSet query_price_mark(int max_price, String mark) throws SQLException
    {        
        price_mark_st.setString(1, mark);
        price_mark_st.setInt(2, max_price);
        return price_mark_st.executeQuery();
    };
    
    ResultSet query_all() throws SQLException
    {
        return all_st.executeQuery();
    };
    
    ResultSet query_par(String max_price, String mark) throws SQLException, NumberFormatException
    {   
        int i_max_price = 0;
        if (!max_price.isEmpty())
            i_max_price = Integer.parseInt(max_price);
        if
                (   (max_price.isEmpty())&&(mark.isEmpty()) )
                        {
                            return query_all();
                        }
                else
                {
                    if ((max_price.isEmpty()))
                        return query_mark(mark);
                    else
                        if ((mark.isEmpty()))
                            return query_price(i_max_price);
                        else
                            return query_price_mark(i_max_price, mark);
                }
    };
    
    ResultSet query(String q) throws SQLException
    {
        return st.executeQuery(q);
    };
}
 
public class WindowApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try
        {
        Class.forName("org.postgresql.Driver");  // Динамическая загрузка драйвера СУБД (класс org.postgresql.Driver) 
        } catch (ClassNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Драйвер СУБД не найден!");
            System.exit(0);
        };
        
                try
        {
        AutoDataBase a;

            a = new AutoDataBase();
       
        
        JFrame fr = new JFrame("Моя первая swing-программа");
        fr.setBounds(100, 100, 700, 500);
        fr.setLayout(null);
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JButton bt = new JButton("Закрыть");
        bt.setBounds(500, 400, 150, 30);
        bt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ev) {
                fr.dispose();
            }
        });
        
        JLabel lbl = new JLabel("Марка автомобиля");
        lbl.setBounds(10, 30, 200, 30);
                
        JLabel lbl1 = new JLabel("Максимальная цена");
        lbl1.setBounds(450, 30,200, 30);
                
/*        JTextField mark = new JTextField("");
       mark.setBounds(10, 70, 400, 30);*/
       JComboBox mark = new JComboBox();
       mark.setBounds(10, 70, 400, 30);
       
       ResultSet marklist = a.query("SELECT DISTINCT \"mark\" FROM \"Autos\"");
       mark.addItem("");
       while (marklist.next())
       {
            mark.addItem(marklist.getString(1));
       };
              
        JTextField price = new JTextField("");
        price.setBounds(450, 70, 200, 30);        
        

        
        
        JButton btclr = new JButton("Очистить фильтр");
        btclr.setBounds(50, 400, 150, 30);
        btclr.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev)
            {
      //          mark.setText("");
                price.setText("");
            };
        });
        
                
        AutoTableModel tblmod = new AutoTableModel();
        
        tblmod.fromQuery(a.query_all());
        
        JTable  tbl = new JTable(tblmod);
                
        JScrollPane sp = new JScrollPane(tbl);
        sp.setBounds(10, 110, 650, 280);   
        
        
        
        JButton btfilt = new JButton("Фильтр");
        btfilt.setBounds(220, 400, 150, 30);
        btfilt.addActionListener(new ActionListener ()
        {
          public void actionPerformed(ActionEvent ev)  
          {
              try
              {
/*                if (price.getText().isEmpty())
                    tblmod.fromQuery(a.query("SELECT * FROM \"Autos\"")); else
                tblmod.fromQuery(a.query_price(Integer.parseInt(price.getText())));*/
                  
//                tblmod.fromQuery(a.query_par(price.getText(), mark.getText()));
                  
                 tblmod.fromQuery(a.query_par(price.getText(), mark.getItemAt(
                         (mark.getSelectedIndex())
                         instanceof String)) );
                        
                tbl.updateUI();
/*                tbl.setVisible(false);
                tbl.setVisible(true);*/
              }
              catch (NumberFormatException e)
              {
                  JOptionPane.showMessageDialog(fr, "Цена не число!");
              }
              catch (SQLException e)
              {
                  JOptionPane.showMessageDialog(fr, "Ошибка выполнения запроса!");
              };
          };
        }
        );
        
        fr.add(bt);
  //      fr.add(mark);
        fr.add(price);
        fr.add(btclr);
        fr.add(lbl);
        fr.add(lbl1);
        fr.add(btfilt);
                
        fr.add(sp);
        
        fr.setVisible(true);     
        
        } catch (SQLException e1)
        {
            System.out.println("SQLException!");
            System.exit(0);
        } catch (ClassNotFoundException e2)
        {            
            System.out.println("ClassNotFoundException!");
            System.exit(0);
        }
    }
    
}
